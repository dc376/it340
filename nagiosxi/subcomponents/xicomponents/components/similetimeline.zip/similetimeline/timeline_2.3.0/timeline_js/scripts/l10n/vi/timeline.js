﻿/*==================================================
 *  Common localization strings
 *==================================================
 */

Timeline.strings["vi"] = {
    wikiLinkLabel: "Bàn luận"
};

