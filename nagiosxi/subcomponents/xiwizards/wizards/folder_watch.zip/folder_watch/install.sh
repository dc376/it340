#!/bin/sh
yum install 'perl(Date::Parse)' -y
exit 0