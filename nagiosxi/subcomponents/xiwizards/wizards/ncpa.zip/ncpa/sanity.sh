#!/bin/bash

#ncpa configwizard sanity check

function zipit() {
	:
}

#~ Include general library (should go in all sanity scripts.)
if [ ! -f /usr/local/nagiosxi/html/includes/components/sanitychecks/sanitylib.sh ];then
    echo "Sanity Checks Component not installed"
    exit 1
else 
    . /usr/local/nagiosxi/html/includes/components/sanitychecks/sanitylib.sh
fi

do_these_files_exist $WIZARDS/ncpa/ncpa.inc.php $LIBEXEC/check_ncpa.py $LIBEXEC/check_icmp

is_wizard $WIZARDS/ncpa/ncpa.inc.php

can_nagios_execute $LIBEXEC/check_ncpa.py $LIBEXEC/check_icmp

can_apache_execute $LIBEXEC/check_ncpa.py $LIBEXEC/check_icmp 

are_these_packages_installed python ncpa 

#are_these_rpms_installed ncpa-head

is_the_sticky_bit_set $LIBEXEC/check_icmp

templates_exist xiwizard_ncpa_service xiwizard_ncpa_host xiwizard_generic_service xiwizard_generic_host

commands_exist check_xi_ncpa_agent check_xi_host_ping

print_results
